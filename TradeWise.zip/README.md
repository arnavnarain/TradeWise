# TradeWise
TradeWise is an iOS app that helps you learn how to trade stocks.

# About
Made by Talal Siddiqui and Arnav Narain for our final project for CS4530: Mobile App Dev at Northeastern University.


