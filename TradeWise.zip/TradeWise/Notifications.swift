//
//  Notifications.swift
//  TradeWise
//
//  Created by user233615 on 6/20/23.
//

import Foundation

extension Notification.Name {
    static let logoutNotification = Notification.Name("logOut")

}
