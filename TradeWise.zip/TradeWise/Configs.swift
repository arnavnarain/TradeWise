//
//  Configs.swift
//  TradeWise
//
//  Created by user233615 on 6/23/23.
//

import Foundation

class Configs {
    static let moduleCellID = "moduleCellID"
    static let lessonCellID = "lessonCellID"
    static let discussionCellID = "discussionCellID"
}
